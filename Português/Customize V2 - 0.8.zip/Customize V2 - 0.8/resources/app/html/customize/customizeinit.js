/* Criado por XinXyla#0001 - Favor não apagar!
Editado por: 
*/

const configFileinit = "./config_customize.json"

config_customize = document.getElementById('config_customize'),
config_customizeset = document.getElementsByClassName("config_customize")[0],

	window.addEventListener("load", function () {
		const fs = require("fs");
		if (fs.existsSync(configFileinit)) {
			fs.readFile(configFileinit, function read(err, data) {
				if (err) throw err;
				var config = JSON.parse(data);
	
	
				config_customize.value = config_customizeset.value = config.config_customize !== undefined ? config.config_customize : "official";
				document.documentElement.style.setProperty("--config-config_customize", document.getElementById("config_customize").value);

			});
		}
		else {
	
			config_customize.value = "official"

			setcustomizeinit()
	
		}
	
	});


	function setcustomizeinit() {
		const fs = require("fs");
		document.documentElement.style.setProperty("--config-config_customize", document.getElementById("config_customize").value);
	
		fs.writeFile(configFileinit, JSON.stringify({"config_customize": config_customize.value}), (err) => { if (err) throw err; });
	}

	function criarcustomize() {
		const fs = require("fs");
			
		config_customizepadrao = "./customize/config_customize_official.json"
		config_customizecheck = "./customize/config_customize_" + document.getElementById("config_customize").value + ".json"

		if (fs.existsSync(config_customizecheck)) {
		} else {
		fs.copyFile(config_customizepadrao, config_customizecheck, (err) => {
			if (err) throw err; 
	  
			  })
			}

}