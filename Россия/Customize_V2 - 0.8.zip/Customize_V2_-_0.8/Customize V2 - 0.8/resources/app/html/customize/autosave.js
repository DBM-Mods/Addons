function iniciarautosave() {
  let customizesalvar = document.getElementById("customizesalvar");
  if (customizesalvar.value == 0) {
    autosavec = setInterval(saveatukak, 15000);
    document.querySelector("[name='saveatual']").innerText = 'Никогда';
  }
  if (customizesalvar.value == 1) {
    autosavec = setInterval(saveProjectmulti, 30000);
    document.querySelector("[name='saveatual']").innerText = 'Каждые 30 секунд';
  } 
  if (customizesalvar.value == 2) {
    autosavec = setInterval(saveProjectmulti, 60000);
    document.querySelector("[name='saveatual']").innerText = 'Каждую 1 минуту';
  } 
  if (customizesalvar.value == 3) {
    autosavec = setInterval(saveProjectmulti, 120000);
    document.querySelector("[name='saveatual']").innerText = 'Каждые 2 минуты';
  }
  if (customizesalvar.value == 4) {
    autosavec = setInterval(saveProjectmulti, 300000);
    document.querySelector("[name='saveatual']").innerText = 'Каждые 5 минут';
  }
  if (customizesalvar.value == 5) {
    autosavec = setInterval(saveProjectmulti, 600000);
    document.querySelector("[name='saveatual']").innerText = 'Каждые 10 минут';
  }
  if (customizesalvar.value == 6) {
    autosavec = setInterval(saveProjectmulti, 900000);
    document.querySelector("[name='saveatual']").innerText = 'Каждые 15 минут';
  }
  if (customizesalvar.value == 7) {
    autosavec = setInterval(saveProjectmulti, 1800000);
    document.querySelector("[name='saveatual']").innerText = 'Каждые 30 минут';
  }
  if (customizesalvar.value == 8) {
    autosavec = setInterval(saveProjectmulti, 2700000);
    document.querySelector("[name='saveatual']").innerText = 'Каждые 45 минут';
  }
  if (customizesalvar.value == 9) {
    autosavec = setInterval(saveProjectmulti, 3600000);
    document.querySelector("[name='saveatual']").innerText = 'Каждые 60 минут';
  }
  if (customizesalvar.value == 10) {
    autosavec = setInterval(saveatukak2, 15000);
    document.querySelector("[name='saveatual']").innerText = 'При создании или редактировании действия';
  }
}

function saveatukak() {
  document.querySelector("[name='saveatual']").innerText = 'Никогда';
}
function saveatukak2() {
  document.querySelector("[name='saveatual']").innerText = 'При создании или редактировании действия';
}

function autosaveupaction() {
  let customizesalvar = document.getElementById("customizesalvar");
  if (customizesalvar.value == 10) {
    saveProjectmulti();
  }
}

function btnActions() {
    const btn = document.getElementById("btnActionsLabel");
    const value = parseInt(document.getElementById("attActionsSelect").value);

    if(value == 0 || value == 3 || value == 6) {
        btn.textContent = "Baixar";
    } else if(value == 1 || value == 4 || value == 7 || value == 9) {
        btn.textContent = "Atualizar";
    } else {
        btn.textContent = "Baixar e atualizar"
    }
}


async function attActions() {
	const select = document.getElementById("attActionsSelect");
	const btn = document.getElementById("btnActions");
	const load = document.getElementById("btnActionsLoad");

	select.style.display = "none";
	btn.style.display = "none";
	load.style.display = "block";

	const value = parseInt(select.value);
	const fs = require("fs");

	const actionsUrl = "https://api.github.com/repos/DBM-Mods/Russia/contents/actions?ref=main";
	const eventsUrl = "https://api.github.com/repos/DBM-Mods/Russia/contents/events?ref=main";
	const botJS = "https://raw.githubusercontent.com/DBM-Mods/Russia/main/bot.js";

	const actionsPath = this.DBM.actLocs.toString();
	const eventsPath = this.DBM.evtLocs.toString();
	const botJSPath = this.DBM.actLocs.toString().slice(0, -7);

	async function fetchAndWrite(url, Path, att) {
		let actions = await fetch(url).then((r) => r.json());
		actions = actions.filter((file) => file.name.toString() != "aaa_dbmmods_dependencies_MODS" && file.download_url != null);
		
		if(att == true) {
			await Promise.all(actions.map(async (action) => {
				const path = `${Path}/${action.name}`;
				const arquivoLocal = fs.existsSync(path) ? fs.readFileSync(path, "utf-8") : null;

				if(arquivoLocal != null) {
					const arquivoFetch = await fetch(action.download_url).then((r) => r.text());

					if(arquivoLocal.toString() != arquivoFetch.toString()) {
						fs.writeFileSync(path, arquivoFetch);
					}
				}
			}));
		} else if(att == "all") {
			await Promise.all(actions.map(async (action) => {
				const path = `${Path}/${action.name}`;
				const arquivoLocal = fs.existsSync(path) ? fs.readFileSync(path, "utf-8") : null;
				const arquivoFetch = await fetch(action.download_url).then((r) => r.text());

				if(arquivoLocal == null) {
					fs.writeFileSync(path, arquivoFetch);
				} else {
					if(arquivoLocal.toString() != arquivoFetch.toString()) {
						fs.writeFileSync(path, arquivoFetch);
					}
				}
			}));
		} else {
			await Promise.all(actions.map(async (action) => {
				const path = `${Path}/${action.name}`;
				const arquivoLocal = fs.existsSync(path) ? fs.readFileSync(path, "utf-8") : null;

				if(arquivoLocal == null) {
					const arquivoFetch = await fetch(action.download_url).then((r) => r.text());
					fs.writeFileSync(path, arquivoFetch);
				}
			}));
		}
	}

	switch(value) {
		case 0:
			await fetchAndWrite(actionsUrl, actionsPath);
			break;
		case 1:
			await fetchAndWrite(actionsUrl, actionsPath, true);
			break;
		case 2:
			await fetchAndWrite(actionsUrl, actionsPath, "all");
			break;
		case 3:
			await fetchAndWrite(eventsUrl, eventsPath);
			break;
		case 4:
			await fetchAndWrite(eventsUrl, eventsPath, true);
			break;
		case 5:
			await fetchAndWrite(eventsUrl, eventsPath, "all");
			break;
		case 6:
			await fetchAndWrite(actionsUrl, actionsPath);
			await fetchAndWrite(eventsUrl, eventsPath);
			break;
		case 7:
			await fetchAndWrite(actionsUrl, actionsPath, true);
			await fetchAndWrite(eventsUrl, eventsPath, true);
			break;
		case 8:
			await fetchAndWrite(actionsUrl, actionsPath, "all");
			await fetchAndWrite(eventsUrl, eventsPath, "all");
			break;
		case 9:
			const file = await fetch(botJS).then((r) => r.text());
			fs.writeFileSync(botJSPath + "bot.js", file);
			break;
	}

	select.style.display = "block";
	btn.style.display = "block";
	load.style.display = "none";
}



function saveProjectmulti() {

if(document.getElementById('bkpsave').checked == false){
	sistemabkp()
}
	
	saveProject()
}

function sistemabkp() {
const fs = require('fs');
const path = require('path');

if (!fs.existsSync(this.DBM.actLocs.toString().slice(0, -7) + "bkp/")) {
    fs.mkdirSync(this.DBM.actLocs.toString().slice(0, -7) + "bkp", {
        recursive: true
    });
}

const sourceFilePath = this.DBM.actLocs.toString().slice(0, -7) + "data/commands.json";
const sourceFilePath2 = this.DBM.actLocs.toString().slice(0, -7) + "data/events.json";
const sourceFilePath3 = this.DBM.actLocs.toString().slice(0, -7) + "data/settings.json";

// obter a data atual
const currentDate = new Date();
const day = currentDate.getDate().toString().padStart(2, '0'); // obter o dia atual com dois dígitos (exemplo: '01' a '31')
const month = (currentDate.getMonth() + 1).toString().padStart(2, '0'); // obter o mês atual com dois dígitos (exemplo: '01' a '12')
const year = currentDate.getFullYear().toString(); // obter o ano atual com quatro dígitos (exemplo: '2023')
const hour = currentDate.getHours().toString().padStart(2, '0'); // obter a hora atual com dois dígitos (exemplo: '00' a '23')
const minute = currentDate.getMinutes().toString().padStart(2, '0'); // obter o minuto atual com dois dígitos (exemplo: '00' a '59')
const second = currentDate.getSeconds().toString().padStart(2, '0'); // obter o segundo atual com dois dígitos (exemplo: '00' a '59')

// criar uma string com o formato "dia-mês-ano hora-minuto-segundo"
const formattedDate = `${day}-${month}-${year} ${hour}-${minute}-${second}`;

if (!fs.existsSync(this.DBM.actLocs.toString().slice(0, -7) + "bkp/" + formattedDate + "/")) {
    fs.mkdirSync(this.DBM.actLocs.toString().slice(0, -7) + "bkp/" + formattedDate, {
        recursive: true
    });
}

const destinationFolderPath = this.DBM.actLocs.toString().slice(0, -7) + "bkp/" + formattedDate + "/";

// obter o nome do arquivo sem a extensão
const fileName = path.basename(sourceFilePath, path.extname(sourceFilePath));
const fileName2 = path.basename(sourceFilePath2, path.extname(sourceFilePath2));
const fileName3 = path.basename(sourceFilePath3, path.extname(sourceFilePath3));

// criar o nome do arquivo com a data atual e a extensão original
const newFileName = `${fileName}${path.extname(sourceFilePath)}`;
const newFileName2 = `${fileName2}${path.extname(sourceFilePath2)}`;
const newFileName3 = `${fileName3}${path.extname(sourceFilePath3)}`;

// copiar o arquivo para a nova pasta com o novo nome
fs.copyFile(sourceFilePath, path.join(destinationFolderPath, newFileName), (err) => {
  if (err) throw err;
});

fs.copyFile(sourceFilePath2, path.join(destinationFolderPath, newFileName2), (err) => {
	if (err) throw err;
  });

  fs.copyFile(sourceFilePath3, path.join(destinationFolderPath, newFileName3), (err) => {
	if (err) throw err;
  });


  const files = fs.readdirSync(this.DBM.actLocs.toString().slice(0, -7) + "bkp", "utf-8");

  const quantidadeBk = window.getComputedStyle(document.documentElement).getPropertyValue('--config-quantidadebk');

  if(parseFloat(quantidadeBk) > 0){
if(files.length >= quantidadeBk) {
    let count = files.length;
    
    for(var i = 0; count > quantidadeBk; i++) {
        fs.unlinkSync(this.DBM.actLocs.toString().slice(0, -7) + "bkp/" + files[i] + "/commands.json");
        fs.unlinkSync(this.DBM.actLocs.toString().slice(0, -7) + "bkp/" + files[i] + "/events.json");
        fs.unlinkSync(this.DBM.actLocs.toString().slice(0, -7) + "bkp/" + files[i] + "/settings.json");
        fs.rmdirSync(this.DBM.actLocs.toString().slice(0, -7) + "bkp/" + files[i]);
        count--;
    }
}
  }

}





