/* Criado por XinXyla#0001 - Favor não apagar!
Editado por: 
*/
function customizebackup(){
const fs = require("fs");


fs.readFile("./config_customize.json", function read(err, data) {
	if (err) throw err;
	var configinit = JSON.parse(data);


fs.copyFile("./customize/config_customize_" + configinit.config_customize+".json", "./customize/bk/config_customize_" + configinit.config_customize+".json", (err) => {
  if (err) throw err;
  var today = new Date();
  var day = today.getDate() + "";
  var month = (today.getMonth() + 1) + "";
  var year = today.getFullYear() + "";
  var hour = today.getHours() + "";
  var minutes = today.getMinutes() + "";
  var seconds = today.getSeconds() + "";
  
  day = checkZero(day);
  month = checkZero(month);
  year = checkZero(year);
  hour = checkZero(hour);
  minutes = checkZero(minutes);
  seconds = checkZero(seconds);

  document.querySelector("[name='customizebk']").innerText = (`Резервное копирование в ${day}/${month}/${year} ${hour}:${minutes}:${seconds}`);
});
})
}

function customizebackupauto(){
	const fs = require("fs");

	
fs.readFile("./config_customize.json", function read(err, data) {
	if (err) throw err;
	var configinit = JSON.parse(data);

	fs.copyFile("./customize/config_customize_" + configinit.config_customize+".json", "./customize/bka/config_customize_" + configinit.config_customize+".json", (err) => {
	  if (err) throw err;
	  var today = new Date();
	  var day = today.getDate() + "";
	  var month = (today.getMonth() + 1) + "";
	  var year = today.getFullYear() + "";
	  var hour = today.getHours() + "";
	  var minutes = today.getMinutes() + "";
	  var seconds = today.getSeconds() + "";
	  
	  day = checkZero(day);
	  month = checkZero(month);
	  year = checkZero(year);
	  hour = checkZero(hour);
	  minutes = checkZero(minutes);
	  seconds = checkZero(seconds);
	
	  document.querySelector("[name='customizebk']").innerText = (`Автоматическое резервное копирование, выполненное в ${day}/${month}/${year} ${hour}:${minutes}:${seconds}`);
	});
})
}

function abrirpasta() {
	const fs = require("fs");
	tetelocal = window.location.pathname
	tetelocal = tetelocal.replace("resources/app/html/index.html","customize")
	tetelocal = tetelocal.replace("/","")
	tetelocal = tetelocal.replaceAll("%20"," ")
	DBM.openLink(tetelocal)
  }

  function vercustomizes() {
	const fs = require("fs");
	tetelocal = window.location.pathname
	tetelocal = tetelocal.replace("resources/app/html/index.html","customize")
	tetelocal = tetelocal.replace("/","")
	pasta = tetelocal.replaceAll("%20"," ")	

	fs.readdir(pasta, (err, arquivos) => {
		if (err) {
		  console.error(err);
		  return;
		}
		const arquivosFiltrados = arquivos.filter(arquivo => {
		  return fs.statSync(`${pasta}/${arquivo}`).isFile();
		});
		const nomesArquivos = arquivosFiltrados.map(arquivo => {
		  return path.parse(arquivo).name;
		});
		document.querySelector("[name='nomescustomizes']").innerText = nomesArquivos.join('\n').replaceAll("config_customize_","");
	  });






  }


function customizerestaurar(){
	const fs = require("fs");

	fs.readFile("./config_customize.json", function read(err, data) {
		if (err) throw err;
		var configinit = JSON.parse(data);

	fs.copyFile("./customize/bk/config_customize_" + configinit.config_customize+".json", "./customize/config_customize_" + configinit.config_customize+".json", (err) => {
	  if (err) throw err;
	  var today = new Date();
	  var day = today.getDate() + "";
	  var month = (today.getMonth() + 1) + "";
	  var year = today.getFullYear() + "";
	  var hour = today.getHours() + "";
	  var minutes = today.getMinutes() + "";
	  var seconds = today.getSeconds() + "";
	  
	  day = checkZero(day);
	  month = checkZero(month);
	  year = checkZero(year);
	  hour = checkZero(hour);
	  minutes = checkZero(minutes);
	  seconds = checkZero(seconds);

	  document.querySelector("[name='customizeres']").innerText = (`Restaurado em ${day}/${month}/${year} ás ${hour}:${minutes}:${seconds}`);


		});
	})
	}

		function customizerestaurar2(){
			const fs = require("fs");

			fs.readFile("./config_customize.json", function read(err, data) {
				if (err) throw err;
				var configinit = JSON.parse(data);
				

			fs.copyFile("./customize/bka/config_customize_" + configinit.config_customize+".json", "./customize/config_customize_" + configinit.config_customize+".json", (err) => {
			  if (err) throw err;
			  var today = new Date();
			  var day = today.getDate() + "";
			  var month = (today.getMonth() + 1) + "";
			  var year = today.getFullYear() + "";
			  var hour = today.getHours() + "";
			  var minutes = today.getMinutes() + "";
			  var seconds = today.getSeconds() + "";
			  
			  day = checkZero(day);
			  month = checkZero(month);
			  year = checkZero(year);
			  hour = checkZero(hour);
			  minutes = checkZero(minutes);
			  seconds = checkZero(seconds);
		
			  document.querySelector("[name='customizeres']").innerText = (`Восстановлен в ${day}/${month}/${year} ${hour}:${minutes}:${seconds}`);
		
		
				});
			})
			}

	function restconfirm1() {
		document.getElementById('restconfirm2').style.display = 'block';
		document.getElementById('restconfirm1').style.display = 'none';
	  }
	  function restconfirm2() {
		document.getElementById('restconfirm1').style.display = 'block';
		document.getElementById('restconfirm2').style.display = 'none';
		document.getElementById('restconfirm3').style.display = 'none';
	  }

	  function restconfirm3() {
		document.getElementById('restconfirm3').style.display = 'block';
		document.getElementById('restconfirm1').style.display = 'none';
	  }


	  function xcustomizerestaurar(){
		const fs = require("fs");

		fs.readFile("./config_customize.json", function read(err, data) {
			if (err) throw err;
			var configinit = JSON.parse(data);
			configFile = "./customize/config_customize_" + configinit.config_customize

		fs.copyFile('./config_customizev07.json', configFile+'.json', (err) => {
		  if (err) throw err;
		  var today = new Date();
		  var day = today.getDate() + "";
		  var month = (today.getMonth() + 1) + "";
		  var year = today.getFullYear() + "";
		  var hour = today.getHours() + "";
		  var minutes = today.getMinutes() + "";
		  var seconds = today.getSeconds() + "";
		  
		  day = checkZero(day);
		  month = checkZero(month);
		  year = checkZero(year);
		  hour = checkZero(hour);
		  minutes = checkZero(minutes);
		  seconds = checkZero(seconds);
	
		  document.querySelector("[name='xcustomizeres']").innerText = (`Восстановлен в ${day}/${month}/${year} ${hour}:${minutes}:${seconds}`);
	
	
			});
		})
		}


			function xrestconfirm1() {
				document.getElementById('xrestconfirm2').style.display = 'block';
				document.getElementById('xrestconfirm1').style.display = 'none';
			  }
	

			  function xrestconfirm2() {
				document.getElementById('xrestconfirm1').style.display = 'block';
				document.getElementById('xrestconfirm2').style.display = 'none';
			  }